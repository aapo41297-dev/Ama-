package com.amali.pageantcoach

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.view.Gravity
import android.widget.*
import android.content.Context

class MainActivity : Activity() {
    private lateinit var content: LinearLayout
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        showDashboard()
    }

    private fun base(title: String): LinearLayout {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(32, 32, 32, 32)
        }
        val heading = TextView(this).apply {
            text = title
            textSize = 26f
            setTextColor(Color.rgb(80, 20, 100))
            setPadding(0,0,0,24)
        }
        root.addView(heading)
        content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
        }
        root.addView(content, LinearLayout.LayoutParams(-1, 0, 1f))
        return root
    }

    private fun button(text: String, action: () -> Unit) =
        Button(this).apply { this.text = text; setOnClickListener { action() } }

    private fun showDashboard() {
        val root = base("Pageant Coach — Version 1")
        content.addView(TextView(this).apply {
            text = "Your coaching command center"
            textSize = 18f
        })
        listOf(
            "Contestants" to ::showContestants,
            "Interview Practice" to ::showInterviews,
            "Training Plans" to ::showTraining,
            "Scores & Reports" to ::showScores,
            "Coach Notes & Ideas" to ::showNotes
        ).forEach { (name, action) -> content.addView(button(name, action)) }
        setContentView(root)
    }

    private fun showContestants() {
        val root = base("Contestants")
        val input = EditText(this).apply { hint = "Contestant name" }
        val list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val prefs = getSharedPreferences("data", Context.MODE_PRIVATE)
        val existing = prefs.getString("contestants", "")!!.split("|").filter { it.isNotBlank() }
        existing.forEach { addLabel(list, it) }
        content.addView(input); content.addView(button("Add Contestant") {
            if (input.text.isNotBlank()) {
                val n = input.text.toString()
                prefs.edit().putString("contestants", (prefs.getString("contestants","") ?: "") + n + "|").apply()
                addLabel(list, n); input.text.clear()
            }
        })
        content.addView(list)
        content.addView(button("Back") { showDashboard() })
        setContentView(root)
    }

    private fun showInterviews() {
        val root = base("Interview Practice")
        content.addView(TextView(this).apply {
            text = "Practice prompts:\n\n• Tell us about yourself.\n• What cause do you want to champion?\n• What would you change in your community?\n• Why should you be a titleholder?\n• Current affairs and Uganda knowledge."
            textSize = 17f
        })
        content.addView(button("Back") { showDashboard() })
        setContentView(root)
    }

    private fun showTraining() {
        val root = base("Training Plans")
        val input = EditText(this).apply { hint = "Training session / goal" }
        content.addView(input)
        content.addView(button("Save Session") {
            if (input.text.isNotBlank()) {
                Toast.makeText(this, "Training session saved", Toast.LENGTH_SHORT).show()
                input.text.clear()
            }
        })
        content.addView(button("Back") { showDashboard() })
        setContentView(root)
    }

    private fun showScores() {
        val root = base("Scores & Reports")
        val score = EditText(this).apply { hint = "Score (0–100)"; inputType = 2 }
        val note = EditText(this).apply { hint = "Judge / coach feedback" }
        content.addView(score); content.addView(note)
        content.addView(button("Save Score") {
            Toast.makeText(this, "Score saved", Toast.LENGTH_SHORT).show()
        })
        content.addView(button("Back") { showDashboard() })
        setContentView(root)
    }

    private fun showNotes() {
        val root = base("Coach Notes & Ideas")
        val input = EditText(this).apply { hint = "Write an idea, observation or coaching note"; minLines = 5 }
        content.addView(input)
        content.addView(button("Save Note") {
            if (input.text.isNotBlank()) {
                getSharedPreferences("data", 0).edit()
                    .putString("last_note", input.text.toString()).apply()
                Toast.makeText(this, "Note saved", Toast.LENGTH_SHORT).show()
            }
        })
        content.addView(button("Back") { showDashboard() })
        setContentView(root)
    }

    private fun addLabel(parent: LinearLayout, text: String) {
        parent.addView(TextView(this).apply {
            this.text = "• $text"
            textSize = 17f
            setPadding(0, 12, 0, 12)
        })
    }
}