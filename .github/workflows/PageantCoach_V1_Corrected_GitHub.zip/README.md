# Pageant Coach V1 — Corrected GitHub Build

This is the corrected Version 1 starter project for the Pageant Coach Android app.

Included:
- Contestants
- Interview Practice
- Training Plans
- Scores & Reports
- Coach Notes & Ideas
- Corrected GitHub Actions APK build workflow

## GitHub
Upload the contents of this folder to your repository.

Then open:
Actions → Build Pageant Coach APK → Run workflow

The workflow builds a debug APK and uploads it as:
Pageant-Coach-V1-APK

Note: this package intentionally uses the GitHub runner's Gradle setup rather than requiring a checked-in Gradle wrapper.
