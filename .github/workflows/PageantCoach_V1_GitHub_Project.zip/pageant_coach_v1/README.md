# Pageant Coach V1

Starter Android app for pageant coaching:
- Contestants
- Interview Practice
- Training Plans
- Scores & Reports
- Coach Notes & Ideas
- GitHub Actions APK workflow

## Build
Open in Android Studio and let it sync Gradle, then build the debug APK.
For GitHub Actions, commit the generated Gradle wrapper (`gradlew`, `gradlew.bat`, and `gradle/wrapper/*`) as well.